﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Rubric_Level : Form
    {
        public Rubric_Level()
        {
            InitializeComponent();
            load();
            printRubricLevels();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Insert into RubricLevel(RubricId,Details,MeasurementLevel) values (@rid,@details,@measure)";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int level = calaculateLevel();
            sqlCommand.Parameters.AddWithValue("@rid",comboBox2.Text);
            sqlCommand.Parameters.AddWithValue("@details",textBox2.Text);
            sqlCommand.Parameters.AddWithValue("@measure", level);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric level inserted");
            printRubricLevels();

        }
        private void load()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select Id from Rubric";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while(reader.Read())
            {
                comboBox2.Items.Add(reader["Id"].ToString());
            }
            reader.Close();
            sqlConnection.Close();
        }
        private int calaculateLevel()
        {
            string ans = comboBox1.Text;
            if (ans == "Exceptional")
            {
                return 4;
            }
            else if (ans == "Good")
            {
                return 3;
            }
            else if (ans == "Fair")
            {
                return 2;
            }
            else
            {
                return 1;
            }
        }
        private void printRubricLevels()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from RubricLevel";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection );
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load( reader );
            dataGridView1.DataSource = dataTable;
            reader.Close();
            sqlConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Update RubricLevel set RubricId=@rid,Details=@details,MeasurementLevel=@measure";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            int level = calaculateLevel();
            sqlCommand.Parameters.AddWithValue("@rid", comboBox2.Text);
            sqlCommand.Parameters.AddWithValue("@details", textBox2.Text);
            sqlCommand.Parameters.AddWithValue("@measure", level);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric level updated");
            printRubricLevels();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            int res = 0;
            int id = int.Parse(comboBox2.Text);
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Delete from RubricLevel where RubricId='"+id+"'";
            string query1 = "Select Id from RubricLevel where RubricId='"+id+"'";

            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query1,sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            if(reader.Read())
            {
                res = Convert.ToInt32(reader["Id"]);
            }
            reader.Close();
            string query2 = "Delete from StudentResult where RubricMeasurementId='"+res+"'";
            SqlCommand sqlCommand1 = new SqlCommand(query2,sqlConnection);
            SqlCommand sqlCommand2 = new SqlCommand(query,sqlConnection);
            sqlCommand1.ExecuteNonQuery();
            sqlCommand2.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Rubric level Deleted");
            printRubricLevels();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
            this.Visible = false;
        }
    }
}
