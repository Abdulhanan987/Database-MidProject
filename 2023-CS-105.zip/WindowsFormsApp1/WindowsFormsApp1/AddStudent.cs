﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class AddStudent : Form
    {
        public AddStudent()
        {
            InitializeComponent();
            printStdents();
            loadStaus();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            printStdents();
            int status = 0;
            string text = comboBox1.Text;
            string query1 = "Select LookupId from Lookup where Name ='"+text+"'" ; 

            if (textBox1.Text=="")
            {
                MessageBox.Show("Please Enter Complete Information");
            }
           else
            {
                string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
                SqlConnection sql = new SqlConnection(conn);
                sql.Open();
                string query = "insert into student values(@Fname, @Lname,@Contact,@Email,@RegistrationNumber,@Status)";
                SqlCommand sqlCommand = new SqlCommand(query, sql);
                SqlCommand sqlCommand1 = new SqlCommand(query1, sql);
                SqlDataReader sqlDataReader = sqlCommand1.ExecuteReader();
                if (sqlDataReader.Read())
                {
                    status = int.Parse(sqlDataReader["LookupId"].ToString());
                }
                sqlDataReader.Close();
                sqlCommand.Parameters.AddWithValue("@Fname", textBox1.Text);
                sqlCommand.Parameters.AddWithValue("@Lname", textBox2.Text);
                sqlCommand.Parameters.AddWithValue("@Contact", textBox3.Text);
                sqlCommand.Parameters.AddWithValue("@Email", textBox5.Text);
                sqlCommand.Parameters.AddWithValue("@RegistrationNumber", textBox4.Text);
                sqlCommand.Parameters.AddWithValue("@Status", status);
                sqlCommand.ExecuteNonQuery();
                sql.Close();
                MessageBox.Show("Student Successfully inserted");

                printStdents();
            }
           

        }
        private void loadStaus()
        {
            string conn = " Data Source = ABDULHANANPC\\SQLEXPRESS11; Initial Catalog = ProjectB; Integrated Security = True";
            string query = "Select Name from Lookup where Category ='STUDENT_STATUS' ";
            SqlConnection sql = new SqlConnection(conn);
            sql.Open();
            SqlCommand sqlCommand1 = new SqlCommand(query, sql);
            SqlDataReader reader = sqlCommand1.ExecuteReader();
            while(reader.Read())
            {
                comboBox1.Items.Add(reader["Name"].ToString());
            }
            reader.Close();
            sql.Close();
        }
        private void printStdents()
        {
            string conn = " Data Source = ABDULHANANPC\\SQLEXPRESS11; Initial Catalog = ProjectB; Integrated Security = True";
            SqlConnection sql = new SqlConnection(conn);
            sql.Open();
            string query = "Select * from Student";
            SqlCommand sqlCommand = new SqlCommand( query, sql);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(reader);
            dataGridView1.DataSource = dataTable;
            reader.Close();
            sql.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var myForm  = new Form1();
            myForm.Show();
            this.Visible = false;
        }

        private void textbox1(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(textBox1.Text)==true)
            {
                textBox1.Focus();
                errorProvider1.SetError(this.textBox1, "Pls enter the name");

            }
            else
            {
                errorProvider1.Clear();
            }
        }
    }
}
