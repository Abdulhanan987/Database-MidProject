﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace WindowsFormsApp1
{
    public partial class AssessmentC : Form
    {
        public AssessmentC()
        {
            InitializeComponent();
            LoadData();
            LoadData1();
            printComp();
        }

        private void AssessmentC_Load(object sender, EventArgs e)
        {

        }
        private void LoadData()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select Title from Assessment";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                comboBox1.Items.Add(reader["Title"].ToString());
            }
            reader.Close();
            sqlConnection.Close();
        }
        
        private void LoadData1()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select Details from Rubric";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            while (reader.Read())
            {
                comboBox2.Items.Add(reader["Details"].ToString());
            }
            reader.Close();
            sqlConnection.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            int rubric = Loadd();
            int assesment = Loadd1();
            string query = "Insert into AssessmentComponent(Name,RubricId,TotalMarks,DateCreated,DateUpdated,AssessmentId) values(@Name,@RubricId,@TotalMarks,GETDATE(),GETDATE(),@AssessmentId)";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection );
            sqlCommand.Parameters.AddWithValue("@Name", textBox1.Text);
            sqlCommand.Parameters.AddWithValue("@RubricId", rubric);
            sqlCommand.Parameters.AddWithValue("@TotalMarks",textBox2.Text);
            sqlCommand.Parameters.AddWithValue("@AssessmentId",assesment);
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Assessment Componenet Inserted");
            printComp();

        }
        private int Loadd()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string ans = comboBox2.Text;
            string query = "Select Id from Rubric where Details='"+ans+"'";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection );
            SqlDataReader reader = sqlCommand.ExecuteReader();
            string res="";
            if (reader.Read())
            {
                res = reader["Id"].ToString();
            }
            reader.Close();
            sqlConnection.Close();
            int a = int.Parse(res);
            return a;
        }
        private int Loadd1()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string ans = comboBox1.Text;
            string query = "Select Id from Assessment where Title='" + ans + "'";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader reader = sqlCommand.ExecuteReader();
            string res = "";
            while (reader.Read())
            {
                res = reader["Id"].ToString();
            }
            reader.Close();
            sqlConnection.Close();
            int a = int.Parse(res);
            return a;
        }
        private void printComp()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from AssessmentComponent";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query, sqlConnection );
            SqlDataReader reader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load( reader );
            dataGridView1.DataSource = dataTable;
            reader.Close() ;
            sqlConnection.Close();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";

            int rubric = Loadd();
            int assesment = Loadd1();

            string name = textBox1.Text;
            
            string query = "Update AssessmentComponent Set Name = @name,RubricId = @rubric,TotalMarks=@Total,DateUpdated=GETDATE(),AssessmentId=@ass where Name='"+name+"'";

            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query,sqlConnection);
            sqlCommand.Parameters.AddWithValue("@name",textBox1.Text);
            sqlCommand.Parameters.AddWithValue("@rubric", rubric);
            sqlCommand.Parameters.AddWithValue("@Total", textBox2.Text);
            sqlCommand.Parameters.AddWithValue("@ass", assesment);
            sqlCommand.ExecuteNonQuery();
            MessageBox.Show("Updated Sucessfully");
            printComp();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Delete from AssessmentComponent where Name='"+name+"'";
            string query1 = "Select Id from AssessmentComponent where name='"+name+"'";
            SqlConnection sqlConnection = new SqlConnection( conn );
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand( query,sqlConnection);
            SqlCommand sqlCommand1 = new SqlCommand(query1,sqlConnection);
            SqlDataReader reader = sqlCommand1.ExecuteReader();
            int res = 0;
            if(reader.Read())
            {
                res = Convert.ToInt32(reader["Id"]);
            }
            reader.Close();
            string query2 = "Delete from StudentResult where AssessmentComponentId='"+res+"'";
            SqlCommand sqlCommand2 = new SqlCommand(query2,sqlConnection);
            sqlCommand2.ExecuteNonQuery();
            sqlCommand.ExecuteNonQuery();
            sqlConnection.Close();
            MessageBox.Show("Deleted Successfully");
            printComp();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
            this.Visible = false;
        }
    }
}
