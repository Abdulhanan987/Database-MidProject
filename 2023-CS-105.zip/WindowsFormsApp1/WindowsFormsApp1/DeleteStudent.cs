﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class DeleteStudent : Form
    {
        public DeleteStudent()
        {
            InitializeComponent();
            printStudents();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void Delete_Load(object sender, EventArgs e)
        {
            
            printStudents();
                    
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(maskedTextBox1.Text == "")
            {
                MessageBox.Show("Please Enter the Information");
            }
            else
            {
                string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
                string data = maskedTextBox1.Text;
                string query = "Delete from Student where RegistrationNumber='" + data + "'";
                string query1 = "Select Id from Student where RegistrationNumber= '"+data+"'";
                SqlConnection sqlConnection = new SqlConnection(conn);
                sqlConnection.Open();
                SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
                SqlCommand sqlCommand1 = new SqlCommand(query1, sqlConnection);
                SqlDataReader sqlDataReader = sqlCommand1.ExecuteReader();
                int id = 0;
                if(sqlDataReader.Read())
                {
                    id = sqlDataReader.GetInt32(0);
                }
                sqlDataReader.Close();
                string query2 = "Delete from StudentAttendance where StudentId = '"+id+"'";
                string query3 = "Delete from StudentResult   where StudentId='"+id+"'";
                SqlCommand sqlCommand2 = new SqlCommand(query2, sqlConnection);
                SqlCommand sqlCommand3 = new SqlCommand(query3, sqlConnection);
                sqlCommand3.ExecuteNonQuery();
                sqlCommand2.ExecuteNonQuery();
                sqlCommand.ExecuteNonQuery();
                sqlConnection.Close();
                MessageBox.Show("Student Deleted Successfully");
                printStudents();
            }
          
        }
        private void printStudents()
        {
            string conn = "Data Source=ABDULHANANPC\\SQLEXPRESS11;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "Select * from Student";
            SqlConnection sqlConnection = new SqlConnection(conn);
            sqlConnection.Open();
            SqlCommand sqlCommand = new SqlCommand(query, sqlConnection);
            SqlDataReader sqlDataReader = sqlCommand.ExecuteReader();
            DataTable dataTable = new DataTable();
            dataTable.Load(sqlDataReader);
            dataGridView1.DataSource = dataTable;
            sqlDataReader.Close();
            sqlConnection.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
            this.Visible = false;
        }
    }         
}
